//============================================================
// C17_Maps_Core_Operations.cpp
// CS2 Lab — STL map<T> Core Operations
//
// Complete solution for all 6 experiments.
// Data: Springfield Power Plant employees
//
// Author : V. Matos  —  El Camino College
//============================================================
#include <iostream>
#include <map>
#include <string>
using namespace std;

//------------------------------------------------------------
// Helper — print all entries in a map with a label
//------------------------------------------------------------
void printMap(const map<string, int>& m, const string& label = "") {
    if (!label.empty())
        cout << label << " (size=" << m.size() << "):\n";
    for (const auto& entry : m)
        cout << "  " << entry.first << " -> " << entry.second << "\n";
}

void printMapD(const map<string, double>& m, const string& label = "") {
    if (!label.empty())
        cout << label << " (size=" << m.size() << "):\n";
    for (const auto& entry : m)
        cout << "  " << entry.first << " -> $" << entry.second << "\n";
}

//============================================================
// Experiment 01 — Define and Populate
//============================================================
void experiment01() {
    cout << "\n=== Experiment 01: Define and Populate ===\n";

    // Method 1 — initializer list
    map<string, int> simpsonsMap = {
        { "Homer Simpson",  45 },
        { "Marge Simpson",  42 },
        { "Bart Simpson",   10 },
        { "Lisa Simpson",    8 },
    };

    // Method 2 — operator[]
    simpsonsMap["Maggie Simpson"]  = 1;

    // Method 3 — insert()
    simpsonsMap.insert({ "Ned Flanders", 60 });

    // Method 4 — emplace()
    simpsonsMap.emplace("Montgomery Burns", 104);

    printMap(simpsonsMap, "Springfield characters");
}

//============================================================
// Experiment 02 — Access: operator[], at(), find(), count()
//============================================================
void experiment02() {
    cout << "\n=== Experiment 02: Access ===\n";

    map<string, int> simpsonsMap = {
        { "Homer Simpson", 45 }, { "Marge Simpson", 42 },
        { "Bart Simpson",  10 }, { "Lisa Simpson",   8 },
    };

    // operator[] — DANGER: inserts empty entry if key is missing
    cout << "Homer age (operator[]): " << simpsonsMap["Homer Simpson"] << "\n";

    // at() — safe read, throws out_of_range if key not found
    try {
        cout << "Marge age (at): " << simpsonsMap.at("Marge Simpson") << "\n";
        cout << "Burns age (at): " << simpsonsMap.at("Montgomery Burns") << "\n";
    }
    catch (const out_of_range& e) {
        cout << "  at() error: " << e.what() << "\n";
    }

    // find() — returns iterator, or end() if not found
    auto it = simpsonsMap.find("Bart Simpson");
    if (it != simpsonsMap.end())
        cout << "Found: " << it->first << "  age=" << it->second << "\n";
    else
        cout << "Bart not found.\n";

    it = simpsonsMap.find("Krusty the Clown");
    cout << "Krusty: " << (it != simpsonsMap.end() ? "found" : "not found (expected)") << "\n";

    // count() — existence check, returns 0 or 1
    cout << "Homer in map:  " << (simpsonsMap.count("Homer Simpson")     ? "YES" : "NO") << "\n";
    cout << "Krusty in map: " << (simpsonsMap.count("Krusty the Clown")  ? "YES" : "NO") << "\n";
}

//============================================================
// Experiment 03 — The Duplicate Key Trap
//============================================================
void experiment03() {
    cout << "\n=== Experiment 03: Duplicate Key Trap ===\n";

    map<string, int> m;

    // operator[] OVERWRITES on duplicate
    m["Homer Simpson"] = 45;
    cout << "Homer inserted with age 45: " << m["Homer Simpson"] << "\n";
    m["Homer Simpson"] = 99;            // overwrites
    cout << "Homer after operator[]=99: " <<