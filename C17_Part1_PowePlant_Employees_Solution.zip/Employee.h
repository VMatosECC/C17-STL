#include <iostream>
#include <sstream>
#include <iomanip>
#include <string>
using namespace std;


class Employee {

protected:
    string id;
    string name;
    int    age;
    double salary;
    string department;

public:
    static int deathCounter;            // keep a count of employee deaths 
                                        // to be used later (reduce thrashing)

    static const int MAX_NAME_LEN = 20; // names must be shorter than this length
    static const int MAX_AGE = 75;      // Used to define working age range
    static const int MIN_AGE = 18;

    // Condensed Constructor (utilizes setters for consistent validation/initialization)
    Employee(const string& id = "",
        const  string& name = "",
        int    age = 0,
        double salary = 0.0,
        const  string& department = "") 
    {
        setId(id);
        setName(name);          //set name before age and salary!
        setAge(age);
        setSalary(salary);
        setDepartment(department);
    }

    // Virtual Destructor
    virtual ~Employee() {
        //cout << "+ Employee deleted " << this << " " << getName() << endl;
        deathCounter++;          //FUTURE USE: tray to reduce this number!
    };

    // Setters
    // Style 1: The parameter and data member have same name (say id - ambigous!) 
    // Use this->xxxx to refer to the object's data member (this->age)
    void setId(const string& id)        { this->id = id; } 

    //Style 2: parameter tagged with 'Value' as in nValue, aValue, and so on
    void setName(const string& nValue)    { 
        //Business rule: Reject names longer than 15 characters
        if (nValue.size() > MAX_NAME_LEN) {
            string msg = "ERROR: name is too long - " + nValue;
            throw runtime_error(msg);
        }
        name = nValue; 
    }

    //-----------------------------------------------------------
    // CAUTION: the next two mutators depend on name comparison 
    // which is known to be fragile — any spelling difference
    // in the input file will silently disable this special case.
    //-----------------------------------------------------------
    void setAge(int aValue)                { 
        if (aValue < 0) aValue = 0;  //clamp age
        //Business Rule1: (Priviledge billionaire) Mr Burns' age cannot be questioned
        if (this->name == "Montgomery Burns") {
            age = aValue;
            return;
        }
        //Business Rule2: (other people) employee's age must be in the range 
        if (aValue < MIN_AGE || aValue > MAX_AGE) {
            string msg = "ERROR: Invalid age: " + to_string(aValue) + " Emp: " + this->name;
            throw runtime_error(msg);
        }
        age = aValue;
    }


    void setSalary(double sValue)       { 
        if (sValue < 0.0) sValue = 0.0; //clamp salary

        //Business Rule1: Mr Burns' salary is above the law
        if (this->name == "Montgomery Burns") {
            salary = sValue;
            return;
        }

        //Business Rule2: Only Mr. Burns can make a seven-digits salary
        if (sValue > 999999) {
            string msg = "ERROR: non-executive salary too high " + 
                         to_string(sValue) + " Emp: " + this->name;
            throw runtime_error(msg);
        }
        salary = sValue;
    }

    void setDepartment(const string& department) { this->department = department; }

    // Getters
    string getId()          const { return id; }
    string getName()        const { return name; }
    int    getAge()         const { return age; }
    double getSalary()      const { return salary; }
    string getDepartment()  const { return department; }


    // User-defined methods --------------------------------------------
    // Stringify object using stringstream
    virtual string toString() const {
        ostringstream sout;
        sout << this << " Employee [ID: " << id
            << ", Name: " << name
            << ", Age: " << age
            << ", Salary: $" << fixed << setprecision(2) << salary
            << ", Department: " << department
            << "]";
        return sout.str();
    }

    // Relational operator < (compares IDs for natural order)
    bool operator<(const Employee& other) const {
        return this->id < other.id;
    }

    // Output stream operator
    friend ostream& operator<<(ostream& sout, const Employee& emp) {
        sout << emp.toString();
        return sout;
    }

    // Factory Method to create an Employee from raw string inputs
    static Employee makeEmployeeFromString(
        const string& strId,
        const string& strName,
        const string& strAge,
        const string& strSalary,
        const string& strDept) 
    {
        int    parsedAge = 0;
        double parsedSalary = 0.0;

        //Try to convert age from string to int
        try {
            if (!strAge.empty()) parsedAge = stoi(strAge);
        }
        catch (...) {
            //TODO - write to log file your correction
            parsedAge = 0; // Handle error here
        }

        //Try to convert salary from string to double
        try {
            if (!strSalary.empty()) parsedSalary = stod(strSalary);
        }
        catch (...) {
            //TODO - write to log file your correction
            parsedSalary = 0.0; // Handle error here
        }

        //Assemble the Employee object
        return Employee(strId, strName, parsedAge, parsedSalary, strDept);
    }
};

//Initialize static variable telling population size/deaths
int Employee::deathCounter = 0;