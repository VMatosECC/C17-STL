// C17-Power-Plant-Employees.cpp 

#include "Employee.h"
#include <fstream>
#include <vector>
#include <stdexcept>
using namespace std;

void experiment01() {
    try
    {
        Employee e1("111", "Homer Simpson", 39, 50000.00, "Security");
        cout << "e1 " << e1 << endl;
        Employee e2("222", "Bart Simpson Simpson Simpson", 10, 1000.00, "HR");
        cout << "e2 " << e2 << endl;
    }
    catch (const std::exception& e)
    {
        cout << "experiment01 - " << e.what() << endl;
    }
}

// ------------------------------------------------------------------------
// Test the idea of implementing the makeDatabase utility as
// vector<Employee> makeDatabase() { }
// Observe the value of deathCounter and compare with the one below
// ------------------------------------------------------------------------
void makeDatabase (vector<Employee>& db)
{
	//Tyr to make the Employee database
	//Declare useful string type variables to support safe reading
	string line, sid, sname, sage, ssalary, sdept;

	//Try to open the source disk file holding raw data needed to make employees
	string employeeFilePath = "c:/Users/vmatos/Downloads/PowerPlantEmployees.txt";
	ifstream infile(employeeFilePath);
	if (!infile) {
		cout << "Fatal error - file not found" << endl;
		exit(101); //stop app
	}

	//Reading a comma-separated file holding the Power Plant Employees
	while (getline(infile, line)) //read the whole line
	{
		try
		{
			stringstream sin(line);		//will be used to decompose the record in fields
			getline(sin, sid, ',');     //cout << "I read: [" << sid << "]" << endl;
			getline(sin, sname, ',');   //cout << "I read: [" << sname << "]" << endl;
			getline(sin, sage, ',');    //cout << "I read: [" << sage << "]" << endl;
			getline(sin, ssalary, ','); //cout << "I read: [" << ssalary << "]" << endl;
			getline(sin, sdept, '\n');  //cout << "I read: [" << sdept << "]" << endl;

			//Assemble the Employee object - Allow business rules to be enforced
			Employee e = Employee::makeEmployeeFromString(sid, sname, sage, ssalary, sdept);
			
			//Add object to the database
			db.push_back(e);
		}


		catch (const std::exception& e)
		{
			//TODO - write this messages in a log file
			cout << "experiment02 CATCH -> " << e.what() << endl;
			cout << "RECORD REJECTED    -> " << line << endl << endl;
		}
	}
	cout << "Database created - Total employees: " << db.size() << endl;
}

//----------------------------------------------------------------------
// Test the following option
// void showVector(vector<T> v, const string& caption) 
// Do you observe any differences? What is the deathCounter value?

template <typename T>
void showVector(vector<T>& v, const string& caption) 
{
	cout << endl;
	cout << string(80, '-') << endl << caption << endl;
	cout << "Database size: " <<  v.size() << endl;
	cout << string(80, '-') << endl;

	// Test the option - Again: is there more or less trashing?
	// for (auto item : v) cout << item << endl;
	for (auto& item : v) cout << item << endl;

}



void experiment02(vector<Employee>& db) {
	//Print the Employee-Database using a template function
	showVector(db, "Power Plant Employees");

	//Create a vector holding employees working for the 'Safety' department
	vector<Employee> vsafety;
	for (auto emp : db) {
		if (emp.getDepartment() == "Safety") {
			vsafety.push_back(emp);
		}
	}

	showVector(vsafety, "Safety Dept Employees");

	cout << "#### ACCUMULATIVE POPULATION DEATHS: " << Employee::deathCounter << endl;
}

//-----------------------------------------------------------------------
int main()
{
    //experiment01();		//Test Employee creation under business rules
	
	//Version 1.
	vector<Employee> db;	//Define the memory resident Employee database
	db.reserve(100);		//Good practice - reserve some working space

	//Version 2. (modify makeDatabase signature to adjust with the following)
	//  db = makeDatabase()
	// 

	makeDatabase(db);
	experiment02(db);

    cout << "\nAll done!\n";
}

