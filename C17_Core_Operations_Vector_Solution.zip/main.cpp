//============================================================
// C17_Vector_Lab.cpp
// CS2 Lab — STL vector<int> Core Operations
//
// Complete solution for all 8 experiments.
//
// Author : V. Matos  —  El Camino College
//============================================================
#include <iostream>
#include <vector>
using namespace std;

//------------------------------------------------------------
// Helper — print a vector<T> on one line with label and size
//------------------------------------------------------------
template <class T>
void printVector(const vector<T>& v, const string& label = "") 
{
    cout << label << " size=" << v.size() << endl << "[";

    for (int x : v) cout << x << " ";

    cout << "]" << endl;
}

//============================================================
// Experiment 01 — Define and Populate
//============================================================
void experiment01() {
    cout << "\n=== Experiment 01: Define and Populate ===\n";

    // Method 1 — initializer list
    vector<int> v1 = { 10, 20, 30, 40, 50 };
    printVector(v1, "v1");

    // Method 2 — push_back()
    vector<int> v2;
    for (int i = 1; i <= 5; i++)
        v2.push_back(i * 11);          // 11, 22, 33, 44, 55
    printVector(v2, "v2");

    // Method 3 — assign(count, value)
    vector<int> v3;
    v3.assign(5, 99);                  // five copies of 99
    printVector(v3, "v3");
}

//============================================================
// Experiment 02 — Traverse: Array Notation and Iterators
//============================================================
void experiment02() {
    cout << "\n=== Experiment 02: Traversal ===\n";

    vector<int> v = { 10, 20, 30, 40, 50 };

    // Style 1 — array-style index
    cout << "Array    : ";
    for (int i = 0; i < v.size(); i++)
        cout << "v[" << i << "]=" << v[i] << " ";
    cout << endl;

    // Style 2A — forward iterator
    cout << "Forward  : ";
    for (auto it = v.begin(); it != v.end(); ++it)
        cout << *it << " ";
    cout << endl;

    // Style 2A — forward iterator
    cout << "Forward  : ";
    auto it = v.begin();
    while (it != v.end()) {
        cout << *it << " ";
        it++;
    }
    cout << endl;

    // Style 3 — reverse iterator
    cout << "Backward : ";
    for (auto it = v.rbegin(); it != v.rend(); ++it)
        cout << *it << " ";
    cout << endl;

    // Style 4 — range-for (most concise)
    cout << "Range-for: ";
    for (int x : v)
        cout << x << " ";
    cout << endl;
}

//============================================================
// Experiment 03 — front(), back(), push_back(), pop_back()
//============================================================
void experiment03() {
    cout << "\n=== Experiment 03: front, back, push_back, pop_back ===\n";

    vector<int> v = { 10, 20, 30, 40, 50 };
    printVector(v, "Initial  ");
    cout << "front()=" << v.front() << "  back()=" << v.back() << endl;

    // Modify via front()
    v.front() = 99;
    printVector(v, "front=99 ");

    // push_back() — grow at the end
    v.push_back(60);
    v.push_back(70);
    v.push_back(80);
    printVector(v, "3x push  ");

    // pop_back() — shrink from the end
    // Save the value BEFORE removing — pop_back() returns void!
    while (!v.empty()) {
        cout << "  Removing back=" << v.back()
            << "  remaining size=" << v.size() - 1 << endl;
        v.pop_back();
    }
    cout << "After all pop_backs: size=" << v.size() << endl;
}

//============================================================
// Experiment 04 — emplace_back() vs push_back()
//============================================================
void experiment04() {
    cout << "\n=== Experiment 04: emplace_back vs push_back ===\n";

    vector<int> v1, v2;

    // Alternating push_back and emplace_back
    v1.push_back(10);
    v1.emplace_back(20);
    v1.push_back(30);
    v1.emplace_back(40);
    v1.push_back(50);

    // All emplace_back
    v2.emplace_back(10);
    v2.emplace_back(20);
    v2.emplace_back(30);
    v2.emplace_back(40);
    v2.emplace_back(50);

    printVector(v1, "v1 mixed  ");
    printVector(v2, "v2 emplace");
    cout << "Results equal: " << (v1 == v2 ? "YES" : "NO") << endl;
}

//============================================================
// Experiment 05 — insert() at Any Position
//============================================================
void experiment05() {
    cout << "\n=== Experiment 05: insert() ===\n";

    vector<int> v = { 10, 20, 40, 50 };   // 30 is missing
    printVector(v, "Initial         ");

    // Insert 30 between 20 and 40 (at index 2)
    v.insert(v.begin() + 2, 30);
    printVector(v, "After insert(30)");

    // Insert 5 at the front
    v.insert(v.begin(), 5);
    printVector(v, "After insert(5) ");

    // Insert 99 at the end (same as push_back)
    v.insert(v.end(), 99);
    printVector(v, "After insert(99)");

    cout << "Final size: " << v.size() << endl;
}

//============================================================
// Experiment 06 — erase() and clear()
//============================================================
void experiment06() {
    cout << "\n=== Experiment 06: erase() and clear() ===\n";

    vector<int> v = { 5, 10, 20, 30, 20, 40, 50 };
    printVector(v, "Initial            ");

    // Erase the first element
    v.erase(v.begin());
    printVector(v, "After erase(front) ");

    // Erase the last two elements
    v.erase(v.end() - 2, v.end());
    printVector(v, "After erase(last 2)");

    // Erase all occurrences of 20
    // Must capture erase() return value — it points to the next element
    for (auto it = v.begin(); it != v.end(); ) {
        if (*it == 20)
            it = v.erase(it);   // returns iterator to element after deleted one
        else
            ++it;
    }
    printVector(v, "After erase(20s)   ");

    // clear() — remove all elements
    v.clear();
    cout << "After clear(): size=" << v.size()
        << "  empty=" << (v.empty() ? "true" : "false") << endl;
}

//============================================================
// Experiment 07 — size() and resize()
//============================================================
void experiment07() {
    cout << "\n=== Experiment 07: size() and resize() ===\n";

    vector<int> v = { 10, 20, 30 };
    printVector(v, "Initial      ");

    // Grow to 6 — new elements default to 0
    v.resize(6);
    printVector(v, "resize(6)    ");

    // Grow to 9 — new elements filled with 99
    v.resize(9, 99);
    printVector(v, "resize(9,99) ");

    // Shrink to 4 — elements beyond index 3 discarded
    v.resize(4);
    printVector(v, "resize(4)    ");

    // resize(0) — same effect as clear()
    v.resize(0);
    cout << "resize(0): size=" << v.size()
        << "  (same effect as clear)\n";
}

//============================================================
// Experiment 08 — swap() and assign()
//============================================================
void experiment08() {
    cout << "\n=== Experiment 08: swap() and assign() ===\n";

    vector<int> v1 = { 1, 2, 3 };
    vector<int> v2 = { 10, 20, 30, 40, 50 };

    cout << "Before swap:\n";
    printVector(v1, "  v1");
    printVector(v2, "  v2");

    // swap() — O(1), no element copies at all
    v1.swap(v2);

    cout << "After swap:\n";
    printVector(v1, "  v1");
    printVector(v2, "  v2");

    // assign(n, val) — replace all contents with n copies of val
    v1.assign(3, 77);
    printVector(v1, "v1 assign(3,77)   ");

    // assign with initializer list
    v2.assign({ 100, 200, 300 });
    printVector(v2, "v2 assign({list}) ");
}

//============================================================
// main
//============================================================
int main() {
    experiment01();
    //experiment02();
    //experiment03();
    //experiment04();
    //experiment05();
    //experiment06();
    //experiment07();
    //experiment08();

    cout << "\nAll done!\n";
    return 0;
}