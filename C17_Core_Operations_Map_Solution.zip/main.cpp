//============================================================
// C17_Maps_Core_Operations.cpp
// CS2 Lab — STL map Core Operations
//
// Complete solution for all 6 experiments.
// Data: Springfield Power Plant employees
//
// Author : V. Matos  —  El Camino College
//============================================================
#include <iostream>
#include <map>
#include <string>
using namespace std;

//------------------------------------------------------------
// Helper — print a map<string, int> with a label
//------------------------------------------------------------
void printMap(const map<string, int>& m, const string& label = "") {
    if (!label.empty())
        cout << label << " (size=" << m.size() << "):\n";
    for (const auto& entry : m)
        cout << "  " << entry.first << " -> " << entry.second << "\n";
}

void printMapD(const map<string, double>& m, const string& label = "") {
    if (!label.empty())
        cout << label << " (size=" << m.size() << "):\n";
    for (const auto& entry : m)
        cout << "  " << entry.first << " -> $" << entry.second << "\n";
}

//============================================================
// Experiment 01 — Define and Populate
//============================================================
void experiment01() {
    cout << "\n=== Experiment 01: Define and Populate ===\n";

    // Method 1 — initializer list
    map<string, int> simpsonsMap = {
        { "Homer Simpson",  45 },
        { "Marge Simpson",  42 },
        { "Bart Simpson",   10 },
        { "Lisa Simpson",    8 },
    };

    // Method 2 — operator[]
    simpsonsMap["Maggie Simpson"]  = 1;

    // Method 3 — insert()
    simpsonsMap.insert({ "Ned Flanders", 60 });

    // Method 4 — emplace()
    simpsonsMap.emplace("Montgomery Burns", 104);

    printMap(simpsonsMap, "Springfield characters");
}

//============================================================
// Experiment 02 — Access: operator[], at(), find(), count()
//============================================================
void experiment02() {
    cout << "\n=== Experiment 02: Access ===\n";

    map<string, int> simpsonsMap = {
        { "Homer Simpson", 45 }, { "Marge Simpson", 42 },
        { "Bart Simpson",  10 }, { "Lisa Simpson",   8 },
    };

    // operator[] — DANGER: inserts empty entry if key is missing
    cout << "Homer age (operator[]): "
         << simpsonsMap["Homer Simpson"] << "\n";

    // at() — safe read, throws out_of_range if key not found
    try {
        cout << "Marge age (at): "
             << simpsonsMap.at("Marge Simpson") << "\n";
        cout << "Burns age (at): "
             << simpsonsMap.at("Montgomery Burns") << "\n";
    }
    catch (const out_of_range& e) {
        cout << "  at() error: " << e.what() << "\n";
    }

    // find() — returns iterator or end()
    auto it = simpsonsMap.find("Bart Simpson");
    if (it != simpsonsMap.end())
        cout << "Found: " << it->first
             << "  age=" << it->second << "\n";
    else
        cout << "Bart not found.\n";

    it = simpsonsMap.find("Krusty the Clown");
    cout << "Krusty: "
         << (it != simpsonsMap.end() ? "found" : "not found (expected)")
         << "\n";

    // count() — existence check, returns 0 or 1
    cout << "Homer in map:  "
         << (simpsonsMap.count("Homer Simpson")    ? "YES" : "NO") << "\n";
    cout << "Krusty in map: "
         << (simpsonsMap.count("Krusty the Clown") ? "YES" : "NO") << "\n";
}

//============================================================
// Experiment 03 — The Duplicate Key Trap
//============================================================
void experiment03() {
    cout << "\n=== Experiment 03: Duplicate Key Trap ===\n";

    map<string, int> m;

    // operator[] OVERWRITES on duplicate
    m["Homer Simpson"] = 45;
    cout << "Homer inserted with age 45: " << m["Homer Simpson"] << "\n";
    m["Homer Simpson"] = 99;            // overwrites
    cout << "Homer after operator[]=99: " << m["Homer Simpson"] << "\n";

    // insert() IGNORES duplicate — original value preserved
    m.insert({ "Marge Simpson", 42 });
    cout << "Marge inserted with age 42: " << m["Marge Simpson"] << "\n";

    auto result = m.insert({ "Marge Simpson", 99 });   // ignored
    cout << "insert(Marge, 99) succeeded: "
         << (result.second ? "YES" : "NO") << "\n";
    cout << "Marge age unchanged:         "
         << m["Marge Simpson"] << "\n";

    // emplace() — same behavior as insert() on duplicate
    m.emplace("Bart Simpson", 10);
    auto result2 = m.emplace("Bart Simpson", 99);      // ignored
    cout << "emplace(Bart, 99) succeeded: "
         << (result2.second ? "YES" : "NO") << "\n";
    cout << "Bart age unchanged:          "
         << m["Bart Simpson"] << "\n";
}

//============================================================
// Experiment 04 — Traverse: Range-for and Iterators
//============================================================
void experiment04() {
    cout << "\n=== Experiment 04: Traversal ===\n";

    map<string, int> simpsonsMap = {
        { "Homer Simpson",    45 },
        { "Marge Simpson",    42 },
        { "Bart Simpson",     10 },
        { "Lisa Simpson",      8 },
        { "Montgomery Burns", 104 },
    };

    // Style 1 — range-for (ascending key order)
    cout << "Range-for (A to Z):\n";
    for (const auto& entry : simpsonsMap)
        cout << "  " << entry.first << " -> " << entry.second << "\n";

    // Style 2 — forward iterator
    cout << "\nForward iterator:\n";
    for (auto it = simpsonsMap.begin(); it != simpsonsMap.end(); ++it)
        cout << "  " << it->first << " -> " << it->second << "\n";

    // Style 3 — reverse iterator (descending key order)
    cout << "\nReverse iterator (Z to A):\n";
    for (auto it = simpsonsMap.rbegin(); it != simpsonsMap.rend(); ++it)
        cout << "  " << it->first << " -> " << it->second << "\n";

    // Modify values during traversal
    // Keys are const — only it->second can be changed
    for (auto it = simpsonsMap.begin(); it != simpsonsMap.end(); ++it)
        it->second += 1;     // everyone gets a birthday!

    cout << "\nAfter birthday (+1 to all ages):\n";
    for (const auto& e : simpsonsMap)
        cout << "  " << e.first << " -> " << e.second << "\n";
}

//============================================================
// Experiment 05 — erase() and clear()
//============================================================
void experiment05() {
    cout << "\n=== Experiment 05: erase() and clear() ===\n";

    map<string, int> simpsonsMap = {
        { "Homer Simpson",    45 },
        { "Marge Simpson",    42 },
        { "Bart Simpson",     10 },
        { "Lisa Simpson",      8 },
        { "Maggie Simpson",    1 },
        { "Montgomery Burns", 104 },
    };
    cout << "Initial size: " << simpsonsMap.size() << "\n";

    // Erase by key
    simpsonsMap.erase("Bart Simpson");
    cout << "After erase(Bart): size=" << simpsonsMap.size()
         << "  Bart still there: "
         << (simpsonsMap.count("Bart Simpson") ? "YES" : "NO") << "\n";

    // Erase by iterator
    auto it = simpsonsMap.find("Homer Simpson");
    if (it != simpsonsMap.end())
        simpsonsMap.erase(it);
    cout << "After erase(Homer by iterator): size="
         << simpsonsMap.size() << "\n";

    // Erase all entries with age < 18
    for (auto it2 = simpsonsMap.begin(); it2 != simpsonsMap.end(); ) {
        if (it2->second < 18)
            it2 = simpsonsMap.erase(it2);
        else
            ++it2;
    }
    cout << "After erase(age < 18):\n";
    for (const auto& e : simpsonsMap)
        cout << "  " << e.first << " -> " << e.second << "\n";

    // clear()
    simpsonsMap.clear();
    cout << "After clear(): size=" << simpsonsMap.size()
         << "  empty=" << (simpsonsMap.empty() ? "true" : "false") << "\n";
}

//============================================================
// Experiment 06 — Practical Application: Salary Database
//============================================================
void experiment06() {
    cout << "\n=== Experiment 06: Salary Database ===\n";

    map<string, double> salaryMap = {
        { "Montgomery Burns",  1000000.00 },
        { "Waylon Smithers",     95000.00 },
        { "Homer Simpson",       52000.00 },
        { "Lenny Leonard",       54000.00 },
        { "Carl Carlson",        68000.00 },
        { "Frank Grimes",        58000.00 },
        { "Professor Frink",     88000.00 },
        { "Hans Moleman",        22000.00 },
    };

    printMapD(salaryMap, "Power Plant Salaries");

    // Lookup Homer's salary
    auto it = salaryMap.find("Homer Simpson");
    if (it != salaryMap.end())
        cout << "\nHomer current salary: $" << it->second << "\n";

    // Give Homer a raise using operator[]
    salaryMap["Homer Simpson"] += 5000.00;
    cout << "Homer after raise:    $"
         << salaryMap["Homer Simpson"] << "\n";

    // Try to lower Burns salary with insert() — will be ignored
    auto result = salaryMap.insert({ "Montgomery Burns", 1.00 });
    cout << "Burns insert($1) succeeded: "
         << (result.second ? "YES — salary changed!" : "NO — unchanged")
         << "\n";
    cout << "Burns salary: $" << salaryMap["Montgomery Burns"] << "\n";

    // Count employees earning more than $60,000
    int highEarners = 0;
    for (const auto& e : salaryMap)
        if (e.second > 60000.00) highEarners++;
    cout << "Employees earning > $60,000: " << highEarners << "\n";

    // Find the highest-paid employee
    auto best = salaryMap.begin();
    for (auto it2 = salaryMap.begin(); it2 != salaryMap.end(); ++it2)
        if (it2->second > best->second) best = it2;
    cout << "Highest paid: " << best->first
         << "  $" << best->second << "\n";
}

//============================================================
// main
//============================================================
int main() {
    experiment01();
    experiment02();
    experiment03();
    experiment04();
    experiment05();
    experiment06();

    cout << "\nAll done!\n";
    return 0;
}