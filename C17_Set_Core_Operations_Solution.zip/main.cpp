//============================================================
// C17_Set_Core_Operations.cpp
// CS2 Lab — STL set<T> Core Operations
//
// Complete solution for all 6 experiments.
// Data: Springfield Power Plant characters
//
// Author : V. Matos  —  El Camino College
//============================================================
#include <iostream>
#include <set>
#include <vector>
#include <string>
#include <algorithm>    // set_union, set_intersection, set_difference
#include <iterator>     // inserter
using namespace std;

//------------------------------------------------------------
// Helper — print a set<string> with a label
//------------------------------------------------------------
void printSet(const set<string>& s, const string& label = "") {
    if (!label.empty())
        cout << label << " (size=" << s.size() << "):\n";
    for (const auto& item : s)
        cout << "  " << item << "\n";
}

void printSetInt(const set<int>& s, const string& label = "") {
    cout << label << "  [ ";
    for (int x : s) cout << x << " ";
    cout << "]  size=" << s.size() << "\n";
}

//============================================================
// Experiment 01 — Define, Populate, and Observe Uniqueness
//============================================================
void experiment01() {
    cout << "\n=== Experiment 01: Define, Populate, Uniqueness ===\n";

    // Initializer list — sorted automatically
    set<string> nameSet = {
        "Homer Simpson",
        "Marge Simpson",
        "Bart Simpson",
        "Lisa Simpson",
        "Maggie Simpson",
    };

    // insert()
    nameSet.insert("Ned Flanders");

    // emplace()
    nameSet.emplace("Montgomery Burns");

    // Duplicate — silently ignored; check return value
    auto result = nameSet.insert("Homer Simpson");
    cout << "insert(Homer again) succeeded: "
         << (result.second ? "YES" : "NO -- already exists") << "\n";

    printSet(nameSet, "nameSet");

    // set<int> — duplicates removed, sorted automatically
    set<int> ageSet = { 45, 10, 42, 8, 104, 10, 45 };
    printSetInt(ageSet, "ageSet (dups removed, sorted):");
}

//============================================================
// Experiment 02 — Traverse: Range-for and Iterators
//============================================================
void experiment02() {
    cout << "\n=== Experiment 02: Traversal ===\n";

    set<string> nameSet = {
        "Homer Simpson", "Marge Simpson", "Bart Simpson",
        "Lisa Simpson",  "Montgomery Burns",
    };

    // Style 1 — range-for (ascending order)
    cout << "Range-for (A to Z):\n";
    for (const auto& name : nameSet)
        cout << "  " << name << "\n";

    // Style 2 — forward iterator
    cout << "\nForward iterator:\n";
    for (auto it = nameSet.begin(); it != nameSet.end(); ++it)
        cout << "  " << *it << "\n";

    // Style 3 — reverse iterator (descending order)
    cout << "\nReverse iterator (Z to A):\n";
    for (auto it = nameSet.rbegin(); it != nameSet.rend(); ++it)
        cout << "  " << *it << "\n";

    // Note: *it = "new value" would be a COMPILE ERROR
    // Set elements are immutable through iterators
    cout << "\nNote: set iterators are read-only (const). "
         << "Elements cannot be modified in place.\n";
}

//============================================================
// Experiment 03 — Search: find(), count(), contains()
//============================================================
void experiment03() {
    cout << "\n=== Experiment 03: Search ===\n";

    set<string> nameSet = {
        "Homer Simpson", "Marge Simpson", "Bart Simpson",
        "Lisa Simpson",  "Montgomery Burns",
    };

    // find() — returns iterator or end()
    auto it = nameSet.find("Homer Simpson");
    if (it != nameSet.end())
        cout << "find(Homer): FOUND -> " << *it << "\n";
    else
        cout << "find(Homer): NOT FOUND\n";

    it = nameSet.find("Krusty the Clown");
    cout << "find(Krusty): "
         << (it != nameSet.end() ? "FOUND" : "NOT FOUND (expected)") << "\n";

    // count() — returns 0 or 1
    cout << "count(Homer):  " << nameSet.count("Homer Simpson")    << "\n";
    cout << "count(Krusty): " << nameSet.count("Krusty the Clown") << "\n";

    // contains() — C++20, most readable
    cout << "contains(Bart): "
         << (nameSet.contains("Bart Simpson") ? "YES" : "NO") << "\n";
    cout << "contains(Ned):  "
         << (nameSet.contains("Ned Flanders") ? "YES" : "NO") << "\n";

    // lower_bound and upper_bound
    set<int> ages = { 8, 10, 42, 45, 60, 104 };
    auto lb = ages.lower_bound(40);   // first element >= 40
    auto ub = ages.upper_bound(60);   // first element >  60

    cout << "\nAges >= 40: ";
    for (auto i = lb; i != ages.end(); ++i) cout << *i << " ";

    cout << "\nAges in [40, 60]: ";
    for (auto i = lb; i != ub; ++i) cout << *i << " ";
    cout << "\n";
}

//============================================================
// Experiment 04 — erase() and clear()
//============================================================
void experiment04() {
    cout << "\n=== Experiment 04: erase() and clear() ===\n";

    set<string> nameSet = {
        "Homer Simpson", "Marge Simpson", "Bart Simpson",
        "Lisa Simpson",  "Maggie Simpson", "Montgomery Burns",
    };
    cout << "Initial size: " << nameSet.size() << "\n";

    // Erase by value
    nameSet.erase("Bart Simpson");
    cout << "After erase(Bart): size=" << nameSet.size()
         << "  Bart present: "
         << (nameSet.count("Bart Simpson") ? "YES" : "NO") << "\n";

    // Erase by iterator
    auto it = nameSet.find("Homer Simpson");
    if (it != nameSet.end())
        nameSet.erase(it);
    cout << "After erase(Homer by iterator): size=" << nameSet.size() << "\n";

    cout << "Remaining: ";
    for (const auto& n : nameSet) cout << n << "  ";
    cout << "\n";

    // Erase all ages below 18 from a set<int>
    set<int> ages = { 1, 8, 10, 42, 45, 60, 104 };
    printSetInt(ages, "Ages before:");

    for (auto it2 = ages.begin(); it2 != ages.end(); ) {
        if (*it2 < 18)
            it2 = ages.erase(it2);   // erase() returns iterator to next element
        else
            ++it2;
    }
    printSetInt(ages, "Ages after erase(<18):");

    // clear()
    nameSet.clear();
    cout << "After clear(): size=" << nameSet.size()
         << "  empty=" << (nameSet.empty() ? "true" : "false") << "\n";
}

//============================================================
// Experiment 05 — Set Operations: Union, Intersection, Difference
//============================================================
void experiment05() {
    cout << "\n=== Experiment 05: Set Operations ===\n";

    // setA — day-shift employees
    set<string> setA = {
        "Homer Simpson",
        "Lenny Leonard",
        "Carl Carlson",
        "Frank Grimes",
        "Barney Gumble",
    };

    // setB — union members
    set<string> setB = {
        "Homer Simpson",
        "Lenny Leonard",
        "Moe Szyslak",
        "Barney Gumble",
        "Otto Mann",
    };

    // Union — A OR B
    set<string> unionSet;
    set_union(setA.begin(), setA.end(),
              setB.begin(), setB.end(),
              inserter(unionSet, unionSet.begin()));
    printSet(unionSet, "Union (A OR B)");

    // Intersection — A AND B
    set<string> interSet;
    set_intersection(setA.begin(), setA.end(),
                     setB.begin(), setB.end(),
                     inserter(interSet, interSet.begin()));
    printSet(interSet, "\nIntersection (A AND B)");

    // Difference — A minus B
    set<string> diffSet;
    set_difference(setA.begin(), setA.end(),
                   setB.begin(), setB.end(),
                   inserter(diffSet, diffSet.begin()));
    printSet(diffSet, "\nDifference (A minus B -- day-shift, non-union)");
}

//============================================================
// Experiment 06 — Practical Application: Deduplication
//============================================================
void experiment06() {
    cout << "\n=== Experiment 06: Deduplication ===\n";

    // Raw department list with duplicates
    vector<string> raw = {
        "Sector 7-G", "Maintenance", "Sector 7-G", "Engineering",
        "Safety",     "Sector 7-G", "Maintenance", "Research",
        "Safety",     "Engineering","Executive",   "Maintenance",
        "Sector 7-G", "IT",         "Research",    "Safety",
        "Executive",  "IT",         "Maintenance", "Sector 7-G",
    };
    cout << "Raw list size (with duplicates): " << raw.size() << "\n";

    // Construct set directly from the vector — duplicates silently discarded
    set<string> deptSet(raw.begin(), raw.end());
    cout << "Unique departments: " << deptSet.size() << "\n";
    for (const auto& d : deptSet)
        cout << "  " << d << "\n";

    // Critical departments that MUST be staffed
    set<string> critical = {
        "Engineering", "Safety", "Sector 7-G", "Security",
    };

    // Which critical departments are actually staffed?
    set<string> staffedCritical;
    set_intersection(deptSet.begin(),  deptSet.end(),
                     critical.begin(), critical.end(),
                     inserter(staffedCritical, staffedCritical.begin()));
    printSet(staffedCritical, "\nCritical departments that ARE staffed");

    // Which critical departments are NOT staffed?
    set<string> unstaffed;
    set_difference(critical.begin(), critical.end(),
                   deptSet.begin(),  deptSet.end(),
                   inserter(unstaffed, unstaffed.begin()));

    cout << "\nCritical departments NOT staffed:\n";
    if (unstaffed.empty())
        cout << "  All critical departments are staffed.\n";
    else
        for (const auto& d : unstaffed) cout << "  " << d << "\n";
}

//============================================================
// main
//============================================================
int main() {
    experiment01();
    experiment02();
    experiment03();
    experiment04();
    experiment05();
    experiment06();

    cout << "\nAll done!\n";
    return 0;
}