//============================================================
// C17_STL_Algorithms_Lab.cpp
// CS2 Lab — STL Algorithms Core Operations
//
// Complete solution for all 6 experiments.
// Data: Springfield Power Plant employees
//
// Author : V. Matos  —  El Camino College
//============================================================
#include <iostream>
#include <vector>
#include <string>
#include <algorithm>    // sort, find, find_if, count_if, copy, copy_if,
                        // for_each, transform, min_element, max_element,
                        // any_of, all_of, none_of
#include <numeric>      // accumulate
#include <iterator>     // back_inserter, ostream_iterator
using namespace std;

//------------------------------------------------------------
// Shared data structure
//------------------------------------------------------------
struct Employee {
    string name;
    int    age;
    double salary;
    string dept;
};

vector<Employee> makeDB() {
    return {
        { "Homer Simpson",        45,   52000, "Sector 7-G"  },
        { "Lenny Leonard",        46,   54000, "Sector 7-G"  },
        { "Carl Carlson",         47,   68000, "Sector 7-G"  },
        { "Frank Grimes",         38,   58000, "Engineering" },
        { "Professor Frink",      58,   88000, "Research"    },
        { "Montgomery Burns",    104, 1000000, "Executive"   },
        { "Waylon Smithers",      52,   95000, "Executive"   },
        { "Hans Moleman",         77,   22000, "Maintenance" },
        { "Ned Flanders",         60,   58000, "Safety"      },
        { "Groundskeeper Willie", 50,   34000, "Maintenance" },
    };
}

//------------------------------------------------------------
// Helper — print employee list with label
//------------------------------------------------------------
void printDB(const vector<Employee>& db, const string& label = "") {
    if (!label.empty()) cout << label << ":\n";
    for (const auto& e : db)
        cout << "  [" << e.dept << "]  " << e.name
             << "  age=" << e.age
             << "  $" << e.salary << "\n";
}

//============================================================
// Experiment 01 — sort()
//============================================================
void experiment01(vector<Employee> db) {   // pass by value — sorts a copy
    cout << "\n=== Experiment 01: sort() ===\n";

    // Sort a plain vector<int>
    vector<int> ages = { 45, 46, 47, 38, 58, 104, 52, 77, 60, 50 };
    sort(ages.begin(), ages.end());
    cout << "Ages ascending: ";
    for (int a : ages) cout << a << " ";
    cout << "\n";

    // Sort by salary descending
    sort(db.begin(), db.end(),
        [](const Employee& a, const Employee& b) {
            return a.salary > b.salary;
        });
    cout << "\nBy salary (highest first):\n";
    for (const auto& e : db)
        cout << "  $" << e.salary << "  " << e.name << "\n";

    // Sort by age ascending
    sort(db.begin(), db.end(),
        [](const Employee& a, const Employee& b) {
            return a.age < b.age;
        });
    cout << "\nBy age (youngest first):\n";
    for (const auto& e : db)
        cout << "  age=" << e.age << "  " << e.name << "\n";

    // Sort by name alphabetically
    sort(db.begin(), db.end(),
        [](const Employee& a, const Employee& b) {
            return a.name < b.name;
        });
    cout << "\nBy name (A to Z):\n";
    for (const auto& e : db)
        cout << "  " << e.name << "\n";

    // Sort by department, then name within department
    sort(db.begin(), db.end(),
        [](const Employee& a, const Employee& b) {
            if (a.dept != b.dept) return a.dept < b.dept;
            return a.name < b.name;
        });
    cout << "\nBy department then name:\n";
    for (const auto& e : db)
        cout << "  [" << e.dept << "]  " << e.name << "\n";
}

//============================================================
// Experiment 02 — find() and find_if()
//============================================================
void experiment02(const vector<Employee>& db) {
    cout << "\n=== Experiment 02: find() and find_if() ===\n";

    // find() on a plain vector<int>
    vector<int> ages = { 45, 46, 47, 38, 58, 104, 52, 77, 60, 50 };
    auto it = find(ages.begin(), ages.end(), 58);
    if (it != ages.end())
        cout << "find(58): found at index " << (it - ages.begin()) << "\n";
    else
        cout << "find(58): not found\n";

    // find_if() — first employee older than 50
    auto it2 = find_if(db.begin(), db.end(),
        [](const Employee& e) { return e.age > 50; });
    if (it2 != db.end())
        cout << "First age > 50: " << it2->name
             << " (age " << it2->age << ")\n";

    // find_if() — first employee in Safety
    auto it3 = find_if(db.begin(), db.end(),
        [](const Employee& e) { return e.dept == "Safety"; });
    if (it3 != db.end())
        cout << "First Safety employee: " << it3->name << "\n";
    else
        cout << "No Safety employees found.\n";

    // find_if() — first earning > $80,000
    auto it4 = find_if(db.begin(), db.end(),
        [](const Employee& e) { return e.salary > 80000; });
    if (it4 != db.end())
        cout << "First earning > $80K: " << it4->name
             << "  $" << it4->salary << "\n";
}

//============================================================
// Experiment 03 — count_if(), any_of(), all_of(), none_of()
//============================================================
void experiment03(const vector<Employee>& db) {
    cout << "\n=== Experiment 03: count_if() and logical checks ===\n";

    // count_if — Maintenance employees
    int maintenance = count_if(db.begin(), db.end(),
        [](const Employee& e) { return e.dept == "Maintenance"; });
    cout << "Maintenance employees: " << maintenance << "\n";

    // count_if — age > 50
    int seniors = count_if(db.begin(), db.end(),
        [](const Employee& e) { return e.age > 50; });
    cout << "Employees age > 50:    " << seniors << "\n";

    // count_if — salary in [50000, 70000]
    int midRange = count_if(db.begin(), db.end(),
        [](const Employee& e) {
            return e.salary >= 50000 && e.salary <= 70000;
        });
    cout << "Salary $50K-$70K:      " << midRange << "\n";

    // any_of — is anyone over 100?
    bool anyOver100 = any_of(db.begin(), db.end(),
        [](const Employee& e) { return e.age > 100; });
    cout << "\nAny employee over 100: " << (anyOver100 ? "YES" : "NO") << "\n";

    // all_of — are all employees adults?
    bool allAdults = all_of(db.begin(), db.end(),
        [](const Employee& e) { return e.age >= 18; });
    cout << "All employees >= 18:   " << (allAdults ? "YES" : "NO") << "\n";

    // none_of — is anyone unpaid?
    bool noneUnpaid = none_of(db.begin(), db.end(),
        [](const Employee& e) { return e.salary == 0; });
    cout << "No unpaid employees:   " << (noneUnpaid ? "YES" : "NO") << "\n";
}

//============================================================
// Experiment 04 — copy() and copy_if()
//============================================================
void experiment04(const vector<Employee>& db) {
    cout << "\n=== Experiment 04: copy() and copy_if() ===\n";

    // copy() — full duplicate
    vector<Employee> backup;
    copy(db.begin(), db.end(), back_inserter(backup));
    cout << "backup size: " << backup.size() << "  (== db size)\n";

    // copy_if() — Sector 7-G only
    vector<Employee> sector7g;
    copy_if(db.begin(), db.end(), back_inserter(sector7g),
        [](const Employee& e) { return e.dept == "Sector 7-G"; });
    cout << "\nSector 7-G employees:\n";
    for (const auto& e : sector7g)
        cout << "  " << e.name << "\n";

    // copy_if() — high earners
    vector<Employee> highEarners;
    copy_if(db.begin(), db.end(), back_inserter(highEarners),
        [](const Employee& e) { return e.salary > 60000; });
    cout << "\nEmployees earning > $60,000:\n";
    for (const auto& e : highEarners)
        cout << "  " << e.name << "  $" << e.salary << "\n";

    // copy() with ostream_iterator — print ages directly
    vector<int> ages = { 45, 38, 58, 104, 52, 77 };
    cout << "\nAges via ostream_iterator: ";
    copy(ages.begin(), ages.end(),
         ostream_iterator<int>(cout, " "));
    cout << "\n";
}

//============================================================
// Experiment 05 — for_each() and transform()
//============================================================
void experiment05(vector<Employee> db) {   // by value — transform modifies copy
    cout << "\n=== Experiment 05: for_each() and transform() ===\n";

    // for_each() — print each employee
    cout << "Employee roster:\n";
    for_each(db.begin(), db.end(),
        [](const Employee& e) {
            cout << "  " << e.name << "  $" << e.salary << "\n";
        });

    // for_each() — stateful lambda counts Maintenance workers
    int maintCount = 0;
    for_each(db.begin(), db.end(),
        [&maintCount](const Employee& e) {
            if (e.dept == "Maintenance") maintCount++;
        });
    cout << "\nMaintenance workers (for_each): " << maintCount << "\n";

    // transform() — extract salaries into vector<double>
    vector<double> salaries;
    transform(db.begin(), db.end(), back_inserter(salaries),
        [](const Employee& e) { return e.salary; });
    cout << "\nSalaries: ";
    for (double s : salaries) cout << s << " ";
    cout << "\n";

    // transform() — build formatted label strings
    vector<string> labels;
    transform(db.begin(), db.end(), back_inserter(labels),
        [](const Employee& e) {
            return e.name + " (age " + to_string(e.age) + ")";
        });
    cout << "\nFormatted labels:\n";
    for (const auto& lbl : labels) cout << "  " << lbl << "\n";

    // transform() — 10% raise written back in place
    transform(db.begin(), db.end(), db.begin(),
        [](Employee e) { e.salary *= 1.10; return e; });
    cout << "\nAfter 10% raise:\n";
    for (const auto& e : db)
        cout << "  $" << e.salary << "  " << e.name << "\n";
}

//============================================================
// Experiment 06 — accumulate(), min_element(), max_element()
//============================================================
void experiment06(const vector<Employee>& db) {
    cout << "\n=== Experiment 06: accumulate, min/max_element ===\n";

    // accumulate() — total payroll (use 0.0 for floating-point sum)
    double totalPayroll = accumulate(db.begin(), db.end(), 0.0,
        [](double sum, const Employee& e) {
            return sum + e.salary;
        });
    cout << "Total payroll:      $" << totalPayroll << "\n";

    // accumulate() — payroll excluding Burns
    double payrollNoBurns = accumulate(db.begin(), db.end(), 0.0,
        [](double sum, const Employee& e) {
            return (e.name != "Montgomery Burns") ? sum + e.salary : sum;
        });
    cout << "Payroll (ex Burns): $" << payrollNoBurns << "\n";

    // Average salary
    cout << "Average salary:     $" << totalPayroll / db.size() << "\n";

    // min/max age
    auto youngest = min_element(db.begin(), db.end(),
        [](const Employee& a, const Employee& b) { return a.age < b.age; });
    auto oldest   = max_element(db.begin(), db.end(),
        [](const Employee& a, const Employee& b) { return a.age < b.age; });
    cout << "\nYoungest: " << youngest->name << " (age " << youngest->age << ")\n";
    cout << "Oldest:   " << oldest->name   << " (age " << oldest->age   << ")\n";

    // min/max salary
    auto lowestPaid  = min_element(db.begin(), db.end(),
        [](const Employee& a, const Employee& b) { return a.salary < b.salary; });
    auto highestPaid = max_element(db.begin(), db.end(),
        [](const Employee& a, const Employee& b) { return a.salary < b.salary; });
    cout << "Lowest paid:  " << lowestPaid->name
         << "  $" << lowestPaid->salary << "\n";
    cout << "Highest paid: " << highestPaid->name
         << "  $" << highestPaid->salary << "\n";
}

//============================================================
// main
//============================================================
int main() {
    vector<Employee> db = makeDB();

    experiment01(db);   // sort — pass by value (sorts a copy)
    experiment02(db);   // find, find_if
    experiment03(db);   // count_if, any_of, all_of, none_of
    experiment04(db);   // copy, copy_if
    experiment05(db);   // for_each, transform — pass by value
    experiment06(db);   // accumulate, min/max_element

    cout << "\nAll done!\n";
    return 0;
}